# AutoPulse — Approved icon assets (2026-10-15)

Source: user-approved AutoPulse neon car/gauge/pulse image; no redesign.

Drop the files in this package into the same paths within the repository.
The Expo icon, adaptive foreground, Play Store 512x512 and native Android mipmap
variants are included. Existing splash screen remains intentionally unchanged.

Recommended native icon background: #061B31 in colors.xml (`iconBackground`)
and app.json `android.adaptiveIcon.backgroundColor`.

This archive only stages assets locally; it is not evidence that the binary
files have been uploaded to GitHub or bundled into an APK.
